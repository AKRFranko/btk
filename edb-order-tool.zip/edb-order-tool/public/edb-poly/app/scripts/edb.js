(function(document) {
  'use strict';
  // ?filter[limit]=15
  var MATERIALS;
  var PRODUCTS;
  var catalog;
  var materials;
  // var materials;
  // var cart;
  var $ = jQuery;
  var getCount = function() {
    var defer = jQuery.Deferred();
    defer.resolve({
      count: 12
    })
    return defer;

    return $.getJSON(apiUrl('/products/count'));
  };
  var apiUrl = function(path) {
    var ck = 'ck_dbc3f91b5f982189037625df93c50393ad99592b';
    var cs = 'cs_9c2a41175bc6d02ef71de28ac1df33d538d8dac1';
    return 'https://'+ck+':'+cs+'@elementdebase.com/wc-api/v3' + path;
  }

  var getChunk = function(start, total, notify) {
    var url = apiUrl('/products?filter[offset]=' + start + '&filter[limit]=' + 5);
    var op = function(outputs) {
      var ajax = $.getJSON(url);
      return ajax.then(function(data) {
        outputs = outputs.concat(data.products);
        notify(Math.floor(100 * (outputs.length / total)));
        return outputs;
      });
    }
    return op;
  }

  var loadProducts = function() {
    var defer = jQuery.Deferred();
    // var outputs=[];
    var resolve = function(outputs) {
      return defer.resolve(outputs.reduce(function(obj, out) {
        obj[String(out.id)] = out;
        return obj;
      }, {}))
    }
    var reject = function(error) {
      return defer.reject(error);
    }
    getCount().then(function(data) {
      var count = data.count;
      var ops = [];
      // var last = getChunk( 1, 5 );
      for (var i = 0; i < count; i += 5) {
        ops.push(getChunk(i, count, defer.notify));


      }
      var op = ops.shift()([]);
      return ops.reduce(function(a, b) {
        return a.then(b);
      }, op).then(resolve, reject)

    }, reject);
    return defer;
  }
  var loadMaterials = function() {
    return $.getJSON('/wp-content/themes/edb-theme/js/materials.json').done(function(data) {

      return data[0];
    });
  }

  //   function Catalog(products, materials) {
  //     this.products = products;
  //     Catalog.materials = materials;
  //     this.materials = materials;
  //     Object.keys(materials).forEach(function(key) {
  //       var title = Catalog.materials[key].title;
  //       var subtitle = Catalog.materials[key].subtitle;
  //       if (subtitle) {
  //         Catalog.materials[key].title = (title + '_' + subtitle.slice(subtitle.indexOf('{:en}') + 5, subtitle.indexOf('{:}'))).toLowerCase();
  //       }

  //     })
  //     var queryCache = {};
  //     var listings = [];

  //     Object.defineProperty(this, 'listing', {
  //       enumerable: true,
  //       get: function() {
  //         return listings;
  //       },
  //       set: function(query) {
  //         if (!query) {
  //           var prods = this.products;
  //           listings = Object.keys(prods).map(function(key) {
  //             return Catalog.ProductProxy(prods[key])
  //           });
  //         } else {
  //           if (!queryCache[query]) {
  //             queryCache[query] = this.findByScore(query, 0.8);
  //           }
  //           listings = queryCache[query];
  //         }
  //       }
  //     });
  //     return this;
  //   };

  // Catalog.ProductProxy = function(data) {
  //   if (typeof data !== 'object') {
  //     return data;
  //   }
  //   // console.log('Catalog.ProductProxy', data)
  //   return new Proxy(data, {
  //     get: function(o, k) {

  //       if (Catalog.hasOwnProperty('get' + k)) {
  //         return Catalog['get' + k](data)
  //       }
  //       return o[k];
  //     },
  //     set: function(o, k, v) {
  //       // console.log('sets', k, v )
  //       o[k] = v;
  //       return true;
  //     }
  //   })
  // };

  // Catalog.getvariations = function(o) {
  //   return o.variations.map(Catalog.ProductProxy).map(function(v) {
  //     v.product = o;



  //     return v;
  //   })
  // }

  // Catalog.getmaterial = function(o) {
  //   var mat = o.attributes[0].options || o.attributes[0].option;
  //   if (Array.isArray(mat)) {
  //     return mat.map(function(i) {
  //       return Catalog.materials[i];
  //     })
  //   } else {
  //     return Catalog.materials[mat];
  //   }

  // }



  // Catalog.getsubtitle = function(o) {
  //   if (( !! o.subtitle) && o.subtitle.includes('{:}')) {
  //     return o.subtitle.slice(o.subtitle.indexOf('{:en}') + 5, o.subtitle.indexOf('{:}'))
  //   } else {
  //     return o.subtitle;
  //   }
  // }
  // Catalog.gettitle = function(o) {
  //   var subtitle = Catalog.getsubtitle(o);
  //   if (subtitle) {
  //     return [o.title, subtitle].join('_');
  //   }
  //   return o.title.replace(/-/g, '_');
  // }



  // Catalog.prototype = {
  //   constructor: Catalog,
  //   createCart: function() {
  //     return new Cart();
  //   },
  //   createOrder: function() {
  //     return new Order();
  //   },
  //   each: function(fn) {
  //     var it = this;
  //     // var 
  //     var products = this.products;
  //     // var get = this.get;
  //     console.log('each', it.products)
  //     return Object.keys(it.products).map(function(key) {
  //       return fn.call(it, it.get(key));
  //     });
  //   },
  //   put: function(id, product) {
  //     id = id.toString();
  //     this.products[id] = product;
  //   },
  //   get: function(id) {
  //     var it = this;
  //     id = id.toString();
  //     var product = this.products[id]
  //     if (product) {
  //       return Catalog.ProductProxy(product);
  //     } else {
  //       var products = this.products;
  //       return Object.keys(it.products).reduce(function(found, productKey) {
  //         var prod = products[productKey];
  //         return found ? found : prod.variations.reduce(function(_found, vari) {
  //           return _found ? _found : vari.id == id ? vari : null;
  //         })
  //         return fn.call(it, it.get(key));
  //       }, null);
  //     }
  //   },
  //   findById: function(ids) {
  //     if (!Array.isArray(ids)) {
  //       ids = [ids];
  //     }
  //     return ids.map(function(id) {
  //       return this.get(id);
  //     }, this).filter(function(v) {
  //       return !!v
  //     });
  //   },
  //   findByAttr: function(attr, value) {
  //     var products = this.products;
  //     return Object.keys(products).reduce(function(found, key) {
  //       var product = products[key];

  //       if (products[key] && product.hasOwnProperty(attr) && product[key] == value) {
  //         found.push(product);
  //       }
  //       return found;
  //     }, [])
  //   },
  //   findByScore: function(string, minScore) {
  //     var it = this;
  //     minScore || (minScore = 0.8);
  //     if (!it.scores) {
  //       it.scores = {};
  //     }
  //     if (!it.scores[string]) {
  //       it.scores[string] = {};
  //     }
  //     it.each(function(product) {
  //       var title = product.title;
  //       var score = LiquidMetal.score(title, string);
  //       it.scores[string][product.id] = score;
  //     })
  //     var ids = Object.keys(it.scores[string]);

  //     return ids.sort(function(a, b) {
  //       if (it.scores[string][a] > it.scores[string][b]) {
  //         return -1;
  //       }
  //       if (it.scores[string][a] < it.scores[string][b]) {
  //         return 1;
  //       }
  //       return 0;
  //     }).filter(function(id) {
  //       return it.scores[string][id] >= minScore
  //     }).map(function(id) {
  //       console.log('map', id)
  //       return it.get(id)
  //     });
  //   }

  // };

  // var getToken = function() {
  //   return Date.now().toString(36);
  // }


  //   function Order() {

  //     this.billing_address = {};
  //     this.shipping_address = {};
  //     this.payment_details = {
  //       method_id: 'wc_gateway_paypal_pro',
  //       method_title: 'Credit Card (paypal)',
  //       paid: false
  //     };
  //     this.line_items = [];
  //     return this;
  //   };

  // Order.prototype = {
  //   toJSON: function() {
  //     return {
  //       order: {
  //         payment_details: this.payment_details,
  //         billing_address: this.billing_address,
  //         shipping_address: this.shipping_address,
  //         line_items: cart.line_items
  //       }
  //     };
  //   },
  //   validate: function() {
  //     if (!this.billing_address.email) {
  //       return new Error('Missing billing email.');
  //     } else if (cart.line_items.length < 1) {
  //       return new Error('No products in cart.');
  //     } else {
  //       return true;
  //     }
  //   },
  //   populate: function(scope, data) {
  //     Object.assign(this[scope], data);
  //   },
  //   send: function() {
  //     this.billing_address.country = 'CA';
  //     this.shipping_address.country = 'CA';
  //     this.billing_address.state = 'QC';
  //     this.shipping_address.state = 'QC';
  //     var ajax = $.ajax({
  //       type: "POST",
  //       url: apiUrl('/orders'),
  //       data: JSON.stringify(this),
  //       dataType: 'json'
  //     });
  //     return ajax;
  //   }
  // };




  // function Cart() {
  //   this.items = {};
  //   Object.defineProperty(this, 'listing', {
  //     enumerable: false,
  //     get: function() {
  //       var items = this.items;
  //       return Object.keys(items).map(function(key) {
  //         var item = items[key];

  //         var variation = catalog.get(item.variation_id);
  //         var product = catalog.get(item.product_id);
  //         // variation.product = product;
  //         return new Proxy(variation, {
  //           get: function(target, k) {

  //             if (k == 'material') {
  //               return catalog.materials[target.attributes[0].option];
  //             }
  //             if (target.hasOwnProperty(k)) {
  //               return target[k];
  //             }
  //             return product[k];
  //           }
  //         });
  //       });
  //     }
  //   })
  //   Object.defineProperty(this, 'line_items', {
  //     enumerable: false,
  //     get: function() {
  //       var items = this.items;
  //       return Object.keys(items).map(function(key) {
  //         var item = items[key];
  //         return item;
  //       });
  //     }
  //   });

  //   return this;
  // }
  // Cart.prototype = {
  //   add: function(product_id, variation_id, qty) {
  //     var token = getToken();

  //     this.items[token] = {
  //       product_id: product_id,
  //       variation_id: variation_id,
  //       quantity: qty
  //     };
  //     return token;
  //   },
  //   update: function(token, qty) {
  //     var item = this.items[token];
  //     item.quantity = qty;
  //     if (qty === 0) {
  //       this.remove(token);
  //     }
  //   },
  //   remove: function(token) {
  //     delete this.items[token];
  //   }
  // }

  function getEn(str) {
    if (str.indexOf('{:}') == -1) return str;
    var eng = str.split('{:}').reduce( function( en, s ){ return en ? en : /\:en/.test( s) ? s : null ;}, null);
    return eng.replace('{:en}', '');
  }

  function proxyMaterial(mat) {
    var data = MATERIALS[mat] || {};
    return new Proxy(data, {
      get: function(targ, key) {
        if (key == 'title') {
          var t = getEn(data.title);
          if (data.subtitle) {
            t = mat + ' ' + t + '_' + getEn(data.subtitle);
          }
          return t;
        }
        return targ[key];
      }
    })
  }

  function proxyVariation(vari, prod) {
    var mat = vari.attributes[0].option;
    return new Proxy(vari, {
      get: function(targ, key) {
        if (key == 'product') {
          return prod;
        }
        if (key == 'material') {
          return proxyMaterial(mat);
        }
        if (targ.hasOwnProperty(key)) {
          return targ[key];
        }
        return prod[key];
      }
    })
  }

  function proxyProduct(product) {

    var pp = new Proxy(product, {
      get: function(targ, key, pxy) {
        var value = targ[key];
        if (typeof value == 'string') {
          value = getEn(value);
        }
        if (key == 'title') {
          var t = getEn(product.title);
          if (product.subtitle) {
            t = t + '_' + getEn(product.subtitle);
          }
          return t;
        }
        if (key == 'category') {
          return targ.categories.join(',');
        }
        if (key == 'material') {
          return Object.keys(MATERIALS).map(function(mat) {
            return proxyMaterial(mat)
          })
        }

        return targ[key];
      }
    });
    // product.variations.sort( function(a,b){
    //   return Number(a.material) - Number(b.material);
    // })
    product.variations = product.variations.map(function(vari) {
      return proxyVariation(vari, pp);
    });
    return pp;
  }

  function tok() {
    return Date.now().toString(36) + (Math.floor(Math.random() * 100000)).toString(36);
  }
  var queryCache = {};
  var CART = {};

  var OT = {
    billing_address: {
      country: 'CA',
      state: 'QC'
    },
    shipping_address: {
      country: 'CA',
      state: 'QC'
    },
    getListing: function(query) {
      if (!query) return [];
      if (!queryCache[query]) {
        queryCache[query] = Object.keys(PRODUCTS).sort(function(a, b) {
          var pA = proxyProduct(PRODUCTS[a]);
          var pB = proxyProduct(PRODUCTS[a]);
          var aScore = LiquidMetal.score(pA.title, query);
          var bScore = LiquidMetal.score(pB.title, query);
          if (!PRODUCTS[a].scores) PRODUCTS[a].scores = {};
          if (!PRODUCTS[b].scores) PRODUCTS[b].scores = {};
          PRODUCTS[a].scores[query] = aScore;
          PRODUCTS[b].scores[query] = bScore;
          if (aScore < bScore) {
            return -1;
          }
          if (aScore > bScore) {
            return 1;
          }
          return 0;
        }).map(function(k) {
          return proxyProduct(PRODUCTS[k]);
        }).filter(function(p) {
          return p.scores[query] >= 0.8;
        });
      }

      window.prod = queryCache[query][0]
      return queryCache[query]
    },
    addToCart: function(pid, varid, qty) {
      var token = tok();
      CART[token] = {
        product_id: pid,
        variation_id: varid,
        quantity: qty,
        cart_token: token
      };
      return token;
    },
    removeFromCart: function(token) {
      delete CART[token];
    },
    getCartListing: function(triggerThing) {
      return Object.keys(CART).map(function(t) {
        var ifo = CART[t];
        var pp = proxyProduct(PRODUCTS[ifo.product_id]);
        var pv = pp.variations.reduce(function(found, v) {
          return found !== null ? found : v.id == ifo.variation_id ? v : null;
        }, null)
        return new Proxy(ifo, {
          get: function(target, key) {
            if (key == 'material') {
              return pv.material;
            }
            return target.hasOwnProperty(key) ? target[key] : pp[key];
          }
        })
      })
    },
    createOrder: function() {
      var billing = OT.billing_address;
      var shipping = OT.billing_address;
      var items = OT.getCartListing().map(function(itm) {
        return {
          product_id: itm.product_id,
          variation_id: itm.variation_id,
          quantity: itm.quantity
        };
      });
      CART = [];

      var ajax = $.ajax({
        type: "POST",
        url: apiUrl('/orders'),
        data: JSON.stringify({
          order: {
            payment_details: {
              method_id: 'wc_gateway_paypal_pro',
              method_title: 'Credit Card (paypal)',
              paid: false
            },
            billing_address: billing,
            shipping_address: shipping,
            line_items: items
          }
        }),
        dataType: 'json'
      });
      return ajax.then(function(data) {
        var h = '/wp-admin/post.php?post=' + data.order.id + '&action=edit';
        window.location.href = h;
      });
    }
  };
  // Product.prototype.getScore = function(str) {
  //   var scoreString = this.title + this.subtitle;
  //   if(!this.scores) this.scores = {};
  //   if(this.scores[str]) return this.scores[str];
  //   this.scores[str] = LiquidMetal.score(scoreString, str);
  //   return this.scores[str];
  // };

  var init = function(onReady) {
    return $.when(loadMaterials(), loadProducts()).done(function(mats, prods) {
      MATERIALS = mats[0];
      PRODUCTS = prods;
      console.log(MATERIALS)
      // var OrderTool=Object.create(Object.prototype);

      onReady(null, OT);
      // onReady(null, (catalog = new Catalog(prods, mats[0])));
    }).fail(onReady);
  };




  if (!window.edb) {
    window.edb = init;
  }


  // init().then(function() {

  //   console.log('init', arguments);
  //   var mm = catalog.findByScore('mix')[0];
  //   cart.add(mm.id, 35995, 3);
  //   var order = new Order();
  //   order.send().then(function() {
  //     console.log('order sent')
  //   }, function(error) {
  //     console.log('order failed', error.responseText);
  //   })
  // });



  // load.progress(function(progress) {
  //   console.log('progress', progress);
  // });

  // load.fail(function(error) {
  //   console.log('failed!', error);
  // });

  // load.done(function(products) {
  //   catalog = new Catalog(products);

  //   console.log('success!', catalog);
  //   catalog.each(function(product) {
  //     console.log(product.title);
  //   })
  // });



  // var get = loadProducts();
  // get.progress( function( progress){
  //   console.log('progress', progress );
  // })
  // get.done( function( products){
  //   console.log('got', products );
  // });
  // get.fail(function( ){
  //           console.log('failed', arguments )
  //         })
  // var app;


  // var loadJSON = function(path) {
  //   return new Promise(function(success, error) {
  //     var xhr = new XMLHttpRequest();
  //     xhr.onreadystatechange = function() {
  //       if (xhr.readyState === XMLHttpRequest.DONE) {
  //         if (xhr.status === 200) {
  //           if (success) success(JSON.parse(xhr.responseText));
  //         } else {
  //           if (error) error(xhr);
  //         }
  //       }
  //     };
  //     xhr.open("GET", path, true);
  //     xhr.send();
  //   })
  // }

  // // $.ajax({
  // //   url: edb_order_tool_params.ajaxurl,
  // //   data: {
  // //     'action': 'edb_order_tool',
  // //     'command': 'initial'
  // //   },
  // //   success: function(data) {
  // //     // This outputs the result of the ajax request
  // //     console.log('success');
  // //     if(data && data.length){
  // //       var data = JSON.parse(data);
  // //       var products = {};
  // //       Object.keys(data).forEach( function( id ){
  // //         var item = data[id];
  // //         products[id] =  new Product( item) ;
  // //       });
  // //       console.log(products)
  // //     }

  // //   },
  // //   error: function(errorThrown) {
  // //     console.log('failure', errorThrown);
  // //   }
  // // });


  // var postCommand = function( command, data ){
  //   return $.ajax({
  //     url: edb_order_tool_params.ajaxurl,
  //     data: {
  //       'action': 'edb_order_tool',
  //       'command': command,
  //       'order': data
  //     },success: function( data ){
  //       console.log('success', data );
  //     },
  //     error: function( data ){
  //       console.log('error', data );
  //     }
  //   })
  // }





  // var Product = function(raw) {
  //   Object.keys(raw).reduce(function(o, k) {
  //     o[k] = raw[k];
  //     return o;
  //   }, this);
  //   return this;
  // };

  // Product.prototype.getScore = function(str) {
  //   var scoreString = this.title + this.subtitle;
  //   if(!this.scores) this.scores = {};
  //   if(this.scores[str]) return this.scores[str];
  //   this.scores[str] = LiquidMetal.score(scoreString, str);
  //   return this.scores[str];
  // };

  // var parseCatalog = function(data) {
  //   var catalog = {};
  //   var products = {};
  //   var variations = {};
  //   var ids = Object.keys(data);
  //   ids.forEach(function(id) {
  //     var product = data[id];
  //     product.hidden = true;
  //     if (product.variation_id === null) {
  //       products[id] = new Product(product);
  //     } else {
  //       if (!variations[product.product_id]) {
  //         variations[product.product_id] = [];
  //       }
  //       variations[product.product_id].push(new Product(product));
  //     }
  //   });
  //   Object.keys(products).reduce(function(cats, pid) {
  //     cats[pid] = products[pid];
  //     cats[pid].variations = variations[pid];
  //     cats[pid].materials = Object.keys(cats[pid].materials).reduce(function(mats, mid) {
  //       if(app.materials[mid]){
  //         mats.push(app.materials[mid]);  
  //       }else{
  //         mats.push({ material: mid, qty_wanted: 0 });
  //       }

  //       return mats;
  //     }, []);
  //     return cats;
  //   }, catalog);
  //   // app.catalog = catalog;
  //   app.catalog = Object.keys(catalog).map(function(k) {
  //     return catalog[k];
  //   });
  // };
  // var toEn = function( str ){
  //   if(/^\{/.test(str.trim())){
  //     return str.match(/^\{\:en\}(.+)\{:\}.+$/)[1];
  //   }
  //   return str;
  // }
  // var parseMaterials = function(data) {
  //   app.materials = Object.keys(data).reduce( function( mats, mid ){
  //     var mat = mats[mid];
  //     mat.name = [mat.material, toEn(mat.title), toEn(mat.subtitle)].join(' ');
  //     mat.qty_wanted=0;
  //     mats[mid] = mat;
  //     return mats;
  //   }, data );
  //   return data;
  // };

  // window.edb = {
  //   use: function(polymerApp) {
  //     app = polymerApp;
  //     app.cart = [];
  //     app.set('orders', [] );
  //     app.set('cart',   []);
  //     app.set('edbLoaded', false);
  //     app.set('shipping_address', { country: 'CA', state: 'QC'}  );
  //     app.set('billing_address', { country: 'CA', state: 'QC'}  );
  //     var variation_id;
  //     app.addToCart = function(e) {
  //       var product = Object.create(app.$.productRepeat.modelForElement(e.target).product);
  //       var material = e.model.material;
  //       if( product.variations.length == 1 ){
  //         variation_id = product.variations[0].variation_id;
  //       }else{
  //       variation_id = product.variations.reduce( function( matched, variation ){
  //         if(matched && matched !== null) return matched;
  //         if(variation.material == material.material) return variation.variation_id;
  //       }, null );  
  //       }

  //       console.log( e.model.material )
  //       product.qty_wanted = material.qty_wanted||1;
  //       product.variation_wanted = variation_id; 
  //       product.available_stock  = product.stocks[variation_id];
  //       product.shipping_delays = product.shipping_delays[variation_id];
  //       product.material_image = material.image;

  //       app.currentTab='cart';
  //       app.push('cart', product); 


  //     }

  //     var isValidShipping = function(){
  //       var shipping_address = app.shipping_address;
  //       var required = app.shipping_address.noship ? [] : ['address_1','postal_code','city','state','country'];

  //       return required.every( function( f ){
  //         return ( typeof shipping_address[f] != 'undefined' && shipping_address[f] !== null && shipping_address[f] !== '');
  //       })
  //     };

  //     var isValidBilling = function(){
  //       var billing_address = app.billing_address;
  //       var required = ['email'];
  //       return required.every( function( f ){
  //         return (typeof billing_address[f] != 'undefined' && billing_address[f] !== null && billing_address[f] !== '');
  //       })
  //     };

  //     app.canSubmit = function( cart, shipping, billing ){
  //       var validCart = app.cart.length > 0;
  //       var validShipping = isValidShipping();
  //       var validBilling = isValidBilling();
  //       return validCart && validShipping && validBilling ;
  //     }
  //     app.removeFromCart = function(e) {
  //       var model = e.model;
  //       var index = model.index;
  //       app.splice('cart', index, 1);
  //     }
  //     // var shippingAddress={};
  //     // app.appendAddress = function( data ){
  //     //   Object.assign(shippingAddress, data)
  //     //   app.hasShippingAddress=true;
  //     //   app.notifyPath('shipping_address', shippingAddress );
  //     // }

  //     app.reset = function(){
  //       app.set('cart', [] );
  //       app.set('searchFilter', null);
  //       app.set('searchInput', null);
  //       app.set('shipping_address', { country: 'CA', state: 'QC'} );
  //       app.set('billing_address', { country: 'CA', state: 'QC'} );
  //       app.currentTab = 'cart';
  //       app.$.errorToast.classList.add('off');
  //     }
  //     app.createOrder = function(){
  //       if(!app.canSubmit()){
  //         app.$.errorToast.classList.remove('off');
  //         setTimeout( function(){
  //           app.$.errorToast.classList.add('off');
  //         }, 500 )
  //         return;
  //       }
  //       app.$.errorToast.classList.add('off');
  //       var cart = app.cart;
  //       var order_items = [];
  //       var item;
  //       while( item = cart.shift() ){
  //         order_items.push( {
  //           product_id: item.product_id,
  //           variation_id: item.variation_wanted,
  //           quantity: item.qty_wanted,
  //         })
  //       }

  //       var order = { items: order_items, shipping_address: app.shipping_address,billing_address: app.billing_address };

  //       postCommand('create_order', order ).then( function( response ){
  //         app.set('finalUrl', response );
  //         app.currentTab = 'final';
  //         app.reset();
  //       });
  //     }
  //     app.addEventListener('dom-change', function() {
  //       loadJSON('json/materials.json').then(parseMaterials).then(function() {
  //         loadJSON('json/catalog.json').then(parseCatalog).then(function() {
  //           app.set('edbLoaded', true);
  //           app.fire('edb-loaded');
  //         }, function(error) {
  //           console.log(error);
  //         });
  //       });
  //     });
  //   }
  // };

})(document);