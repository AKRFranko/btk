(function(document) {
  'use strict';
  var app;

  var loadJSON = function(path) {
    return new Promise(function(success, error) {
      var xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
          if (xhr.status === 200) {
            if (success) success(JSON.parse(xhr.responseText));
          } else {
            if (error) error(xhr);
          }
        }
      };
      xhr.open("GET", path, true);
      xhr.send();
    })
  }
  
  // $.ajax({
  //   url: edb_order_tool_params.ajaxurl,
  //   data: {
  //     'action': 'edb_order_tool',
  //     'command': 'initial'
  //   },
  //   success: function(data) {
  //     // This outputs the result of the ajax request
  //     console.log('success');
  //     if(data && data.length){
  //       var data = JSON.parse(data);
  //       var products = {};
  //       Object.keys(data).forEach( function( id ){
  //         var item = data[id];
  //         products[id] =  new Product( item) ;
  //       });
  //       console.log(products)
  //     }

  //   },
  //   error: function(errorThrown) {
  //     console.log('failure', errorThrown);
  //   }
  // });
  
  
  var postCommand = function( command, data ){
    return $.ajax({
      url: edb_order_tool_params.ajaxurl,
      data: {
        'action': 'edb_order_tool',
        'command': command,
        'order': data
      },success: function( data ){
        console.log('success', data );
      },
      error: function( data ){
        console.log('error', data );
      }
    })
  }
 
  
  
  

  var Product = function(raw) {
    Object.keys(raw).reduce(function(o, k) {
      o[k] = raw[k];
      return o;
    }, this);
    return this;
  };

  Product.prototype.getScore = function(str) {
    var scoreString = this.title + this.subtitle;
    if(!this.scores) this.scores = {};
    if(this.scores[str]) return this.scores[str];
    this.scores[str] = LiquidMetal.score(scoreString, str);
    return this.scores[str];
  };

  var parseCatalog = function(data) {
    var catalog = {};
    var products = {};
    var variations = {};
    var ids = Object.keys(data);
    ids.forEach(function(id) {
      var product = data[id];
      product.hidden = true;
      if (product.variation_id === null) {
        products[id] = new Product(product);
      } else {
        if (!variations[product.product_id]) {
          variations[product.product_id] = [];
        }
        variations[product.product_id].push(new Product(product));
      }
    });
    Object.keys(products).reduce(function(cats, pid) {
      cats[pid] = products[pid];
      cats[pid].variations = variations[pid];
      cats[pid].materials = Object.keys(cats[pid].materials).reduce(function(mats, mid) {
        if(app.materials[mid]){
          mats.push(app.materials[mid]);  
        }else{
          mats.push({ material: mid, qty_wanted: 0 });
        }
        
        return mats;
      }, []);
      return cats;
    }, catalog);
    // app.catalog = catalog;
    app.catalog = Object.keys(catalog).map(function(k) {
      return catalog[k];
    });
  };
  var toEn = function( str ){
    if(/^\{/.test(str.trim())){
      return str.match(/^\{\:en\}(.+)\{:\}.+$/)[1];
    }
    return str;
  }
  var parseMaterials = function(data) {
    app.materials = Object.keys(data).reduce( function( mats, mid ){
      var mat = mats[mid];
      mat.name = [mat.material, toEn(mat.title), toEn(mat.subtitle)].join(' ');
      mat.qty_wanted=0;
      mats[mid] = mat;
      return mats;
    }, data );
    return data;
  };

  window.edb = {
    use: function(polymerApp) {
      app = polymerApp;
      app.cart = [];
      app.set('orders', [] );
      app.set('cart',   []);
      app.set('edbLoaded', false);
      app.set('shipping_address', { country: 'CA', state: 'QC'}  );
      app.set('billing_address', { country: 'CA', state: 'QC'}  );
      var variation_id;
      app.addToCart = function(e) {
        var product = Object.create(app.$.productRepeat.modelForElement(e.target).product);
        var material = e.model.material;
        if( product.variations.length == 1 ){
          variation_id = product.variations[0].variation_id;
        }else{
         variation_id = product.variations.reduce( function( matched, variation ){
          if(matched && matched !== null) return matched;
          if(variation.material == material.material) return variation.variation_id;
        }, null );  
        }
        
        console.log( e.model.material )
        product.qty_wanted = material.qty_wanted||1;
        product.variation_wanted = variation_id; 
        product.available_stock  = product.stocks[variation_id];
        product.shipping_delays = product.shipping_delays[variation_id];
        product.material_image = material.image;
        
        app.currentTab='cart';
        app.push('cart', product); 
        
        
      }

      var isValidShipping = function(){
        var shipping_address = app.shipping_address;
        var required = app.shipping_address.noship ? [] : ['address_1','postal_code','city','state','country'];
        
        return required.every( function( f ){
          return ( typeof shipping_address[f] != 'undefined' && shipping_address[f] !== null && shipping_address[f] !== '');
        })
      };
      
      var isValidBilling = function(){
        var billing_address = app.billing_address;
        var required = ['email'];
        return required.every( function( f ){
          return (typeof billing_address[f] != 'undefined' && billing_address[f] !== null && billing_address[f] !== '');
        })
      };
      
      app.canSubmit = function( cart, shipping, billing ){
        var validCart = app.cart.length > 0;
        var validShipping = isValidShipping();
        var validBilling = isValidBilling();
        return validCart && validShipping && validBilling ;
      }
      app.removeFromCart = function(e) {
        var model = e.model;
        var index = model.index;
        app.splice('cart', index, 1);
      }
      // var shippingAddress={};
      // app.appendAddress = function( data ){
      //   Object.assign(shippingAddress, data)
      //   app.hasShippingAddress=true;
      //   app.notifyPath('shipping_address', shippingAddress );
      // }
      
      app.reset = function(){
        app.set('cart', [] );
        app.set('searchFilter', null);
        app.set('searchInput', null);
        app.set('shipping_address', { country: 'CA', state: 'QC'} );
        app.set('billing_address', { country: 'CA', state: 'QC'} );
        app.currentTab = 'cart';
        app.$.errorToast.classList.add('off');
      }
      app.createOrder = function(){
        if(!app.canSubmit()){
          app.$.errorToast.classList.remove('off');
          setTimeout( function(){
            app.$.errorToast.classList.add('off');
          }, 500 )
          return;
        }
        app.$.errorToast.classList.add('off');
        var cart = app.cart;
        var order_items = [];
        var item;
        while( item = cart.shift() ){
          order_items.push( {
            product_id: item.product_id,
            variation_id: item.variation_wanted,
            quantity: item.qty_wanted,
          })
        }
        
        var order = { items: order_items, shipping_address: app.shipping_address,billing_address: app.billing_address };
        
        postCommand('create_order', order ).then( function( response ){
          app.set('finalUrl', response );
          app.currentTab = 'final';
          app.reset();
        });
      }
      app.addEventListener('dom-change', function() {
        loadJSON('json/materials.json').then(parseMaterials).then(function() {
          loadJSON('json/catalog.json').then(parseCatalog).then(function() {
            app.set('edbLoaded', true);
            app.fire('edb-loaded');
          }, function(error) {
            console.log(error);
          });
        });
      });
    }
  };

})(document);