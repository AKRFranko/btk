// (function($){
//   window.send_to_editor = function(html) {
//       var image_url = $('img',html).attr('src');
//       $('#blog_header_image_url').val(image_url);
//       tb_remove();
//   }
//   $(function($) {
//       $('#upload_blog_header_image_button').click(function() {
//           tb_show('Upload blog header image', 'media-upload.php?referer=edb-blog&type=image&TB_iframe=true&post_id=0', false);
//           return false;
//       });
//   });
// })(jQuery)