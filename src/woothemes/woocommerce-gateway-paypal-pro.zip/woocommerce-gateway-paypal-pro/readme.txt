=== WooCommerce PayPal Pro Gateway ===

A payment gateway for PayPal Pro. A PayPal Pro merchant account, Curl support, and a server with SSL support and an SSL certificate is required (for security reasons) for this gateway to function.

== Important Note ==

You *must* enable SSL from the settings panel to use this plugin in live mode - this is for your customers safety and security.